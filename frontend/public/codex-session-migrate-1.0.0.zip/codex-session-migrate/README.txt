Run inspect first. Review a plan, close Codex, then use apply with its exact digest.
The tool never uploads local history or changes config.toml/authentication files.
